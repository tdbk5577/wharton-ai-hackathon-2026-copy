import { useState, useEffect } from 'react';
import { Mic, ArrowLeft } from 'lucide-react';

interface VoiceReviewModeProps {
  onSubmit: () => void;
  onBackToText: () => void;
}

interface ConversationMessage {
  id: number;
  type: 'ai' | 'user';
  text: string;
}

export function VoiceReviewMode({ onSubmit, onBackToText }: VoiceReviewModeProps) {
  const [isRecording, setIsRecording] = useState(true);
  const [currentStep, setCurrentStep] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const [messages, setMessages] = useState<ConversationMessage[]>([
    { id: 1, type: 'ai', text: "Hi! Let's make this easy. Tell me about your overall experience at the hotel." }
  ]);

  const conversationFlow = [
    "Great! And how would you rate your overall experience on a scale of 1 to 5 stars?",
    "Perfect. Now, how would you rate the cleanliness and condition of your room on a scale of 1 to 5 stars?",
    "Excellent. And how would you rate the hotel staff and service on a scale of 1 to 5 stars?"
  ];

  const userResponses = [
    "The hotel was fantastic! Great location and comfortable rooms.",
    "5 stars",
    "5 stars",
    "5 stars"
  ];

  // Auto-start first recording when component mounts
  useEffect(() => {
    if (currentStep === 0 && messages.length === 1) {
      const timer = setTimeout(() => {
        processUserResponse(0);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, []);

  const processUserResponse = (step: number) => {
    if (isComplete) return;

    setIsRecording(false);

    // Add user response
    setMessages(prev => [...prev, {
      id: prev.length + 1,
      type: 'user',
      text: userResponses[step]
    }]);

    // Determine next action
    setTimeout(() => {
      if (step < conversationFlow.length) {
        // Ask next question
        setMessages(prev => [...prev, {
          id: prev.length + 1,
          type: 'ai',
          text: conversationFlow[step]
        }]);

        const nextStep = step + 1;
        setCurrentStep(nextStep);

        // Auto-start next recording
        setTimeout(() => {
          setIsRecording(true);
          setTimeout(() => {
            processUserResponse(nextStep);
          }, 2500);
        }, 1000);
      } else {
        // All questions answered - complete
        setIsComplete(true);
        setMessages(prev => [...prev, {
          id: prev.length + 1,
          type: 'ai',
          text: "Thank you! Your review has been submitted."
        }]);

        setTimeout(() => {
          onSubmit();
        }, 2000);
      }
    }, 800);
  };

  const handleRecordToggle = () => {
    // Disabled during auto-flow
    return;
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-6 pt-8 pb-4">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-[32px] leading-[1.2] bg-gradient-to-br from-[#000000] to-[#333333] bg-clip-text text-transparent">
            Voice Review
          </h1>

          {/* Back to text button */}
          <button
            onClick={onBackToText}
            className="px-4 py-2 rounded-full transition-all duration-300 flex items-center gap-2
                     bg-white text-foreground shadow-[0_2px_8px_rgba(0,0,0,0.08)]
                     hover:shadow-[0_4px_12px_rgba(0,0,0,0.12)]"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-[13px] font-medium">Text mode</span>
          </button>
        </div>
        <p className="text-[15px] text-muted-foreground">
          Tap to speak, we'll guide you through
        </p>
      </div>

      {/* Conversation area */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 opacity-0 animate-slide-in ${
              message.type === 'user' ? 'flex-row-reverse' : ''
            }`}
            style={{
              animationFillMode: 'forwards',
            }}
          >
            {/* Avatar */}
            <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-md ${
              message.type === 'ai'
                ? 'bg-gradient-to-br from-primary to-primary'
                : 'bg-foreground'
            }`}>
              <span className={message.type === 'ai' ? 'text-foreground text-[14px]' : 'text-background text-[14px]'}>
                {message.type === 'ai' ? '✦' : '👤'}
              </span>
            </div>

            {/* Message bubble */}
            <div className={`flex-1 max-w-[75%] ${
              message.type === 'user' ? 'flex justify-end' : ''
            }`}>
              <div className={`rounded-2xl px-5 py-4 shadow-[0_2px_12px_rgba(0,0,0,0.08)] ${
                message.type === 'ai'
                  ? 'bg-white rounded-tl-md'
                  : 'bg-foreground text-background rounded-tr-md'
              }`}>
                <p className="text-[15px] leading-relaxed">
                  {message.text}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Voice input button */}
      <div className="px-6 pb-6 pt-4">
        <div className="flex flex-col items-center">
          {isRecording && (
            <p className="text-[14px] text-muted-foreground mb-4 animate-pulse">
              Listening...
            </p>
          )}

          <button
            onClick={handleRecordToggle}
            className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 ${
              isRecording
                ? 'bg-primary text-primary-foreground shadow-[0_0_32px_rgba(238,194,24,0.6)] scale-110'
                : 'bg-primary text-primary-foreground shadow-[0_4px_20px_rgba(238,194,24,0.3)]'
            }`}
          >
            <Mic className={`w-8 h-8 ${isRecording ? 'animate-pulse' : ''}`} />

            {isRecording && (
              <>
                <span className="absolute inset-0 rounded-full border-2 border-primary animate-ping opacity-75" />
                <span className="absolute inset-0 rounded-full border border-primary animate-pulse" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* Decorative gradient orbs */}
      <div
        className="fixed top-1/4 right-0 w-64 h-64 rounded-full opacity-15 blur-3xl pointer-events-none -z-10"
        style={{
          background: 'radial-gradient(circle, #EEC218 0%, transparent 70%)',
          animation: 'float-slow 10s ease-in-out infinite',
        }}
      />

      <style>{`
        @keyframes slide-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-slide-in {
          animation: slide-in 0.5s ease-out;
        }
        @keyframes float-slow {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(-20px, 20px); }
        }
      `}</style>
    </div>
  );
}
