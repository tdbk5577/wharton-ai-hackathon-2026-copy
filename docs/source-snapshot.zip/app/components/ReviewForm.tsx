import { useState } from "react";
import { VoiceReviewMode } from "./VoiceReviewMode";
import { Star } from "lucide-react";

interface ReviewFormProps {
  onSubmit: () => void;
}

interface Question {
  id: number;
  category: string;
  text: string;
  answer: string;
  rating: number;
}

export function ReviewForm({ onSubmit }: ReviewFormProps) {
  const [review, setReview] = useState("");
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [overallRating, setOverallRating] = useState(0);
  const [hoveredOverallStar, setHoveredOverallStar] =
    useState(0);
  const [questions] = useState<Question[]>([
    {
      id: 1,
      category: "Cleanliness",
      text: "How was the cleanliness and condition of your room?",
      answer: "",
      rating: 0,
    },
    {
      id: 2,
      category: "Service",
      text: "What was your experience with the hotel staff and service?",
      answer: "",
      rating: 0,
    },
  ]);
  const [answers, setAnswers] = useState<{
    [key: number]: string;
  }>({});
  const [ratings, setRatings] = useState<{
    [key: number]: number;
  }>({});
  const [hoveredStars, setHoveredStars] = useState<{
    [key: number]: number;
  }>({});

  const handleSubmit = () => {
    onSubmit();
  };

  const updateAnswer = (id: number, value: string) => {
    setAnswers((prev) => ({ ...prev, [id]: value }));
  };

  const updateRating = (id: number, value: number) => {
    setRatings((prev) => ({ ...prev, [id]: value }));
  };

  // Voice mode rendering
  if (isVoiceMode) {
    return (
      <VoiceReviewMode
        onSubmit={onSubmit}
        onBackToText={() => setIsVoiceMode(false)}
      />
    );
  }

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      {/* Header */}
      <div className="px-6 pt-8 pb-6 sticky top-0 bg-background z-10">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-[32px] leading-[1.2] bg-gradient-to-br from-[#000000] to-[#333333] bg-clip-text text-transparent">
            Share your experience
          </h1>

          {/* Voice mode toggle */}
          <button
            onClick={() => setIsVoiceMode(!isVoiceMode)}
            className={`px-4 py-2 rounded-full transition-all duration-300 flex items-center gap-2 ${
              isVoiceMode
                ? "bg-primary text-primary-foreground shadow-[0_4px_12px_rgba(238,194,24,0.24)]"
                : "bg-white text-foreground shadow-[0_2px_8px_rgba(0,0,0,0.08)]"
            }`}
          >
            <svg
              className="w-4 h-4"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M7 4a3 3 0 016 0v6a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" />
            </svg>
            <span className="text-[13px] font-medium">
              Voice
            </span>
          </button>
        </div>
        <p className="text-[15px] text-muted-foreground">
          Write your review below or click the voice button for
          a 'hands-free' experience
        </p>
      </div>

      {/* Main review input */}
      <div className="px-6 pb-8">
        {/* Category indicator */}
        <div className="flex items-center gap-2 mb-3">
          <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
            <span className="text-[13px] font-medium">1</span>
          </div>
          <span className="text-[13px] text-muted-foreground">
            Overall Experience
          </span>
        </div>

        {/* Overall experience card */}
        <div className="bg-white rounded-2xl px-5 py-5 shadow-[0_2px_12px_rgba(0,0,0,0.08)]">
          {/* Question text */}
          <p className="text-[15px] leading-relaxed mb-3">
            How was your overall experience at Grand Plaza Hotel
            & Suites?
          </p>

          {/* Category suggestions */}
          <div className="mb-4">
            <p className="text-[13px] text-muted-foreground mb-2">
              Example topics:
            </p>
            <div className="flex flex-wrap gap-2">
              {[
                "Location",
                "Room comfort",
                "Amenities",
                "Value for money",
                "Noise level",
                "Check-in/out",
              ].map((category) => (
                <span
                  key={category}
                  className="px-3 py-1.5 bg-muted/50 text-foreground/70 rounded-full text-[13px]
                           border border-border/50"
                >
                  {category}
                </span>
              ))}
            </div>
          </div>

          {/* Star rating */}
          <div className="flex flex-col items-center mb-4">
            <p className="text-[13px] text-muted-foreground mb-2.5">
              Leave rating
            </p>
            <div className="flex items-center gap-2">
              {Array.from({ length: 5 }).map((_, i) => {
                const starValue = i + 1;
                const isActive =
                  starValue <=
                  (hoveredOverallStar || overallRating);

                return (
                  <button
                    key={i}
                    onClick={() => setOverallRating(starValue)}
                    onMouseEnter={() =>
                      setHoveredOverallStar(starValue)
                    }
                    onMouseLeave={() =>
                      setHoveredOverallStar(0)
                    }
                    className="transition-all duration-200 hover:scale-110 active:scale-95"
                  >
                    <Star
                      className={`w-9 h-9 transition-colors duration-200 ${
                        isActive
                          ? "fill-primary text-primary"
                          : "fill-none text-foreground/40 stroke-[2.5]"
                      }`}
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Divider */}
          <div className="h-px bg-border/50 mb-4" />

          {/* Answer input */}
          <textarea
            value={review}
            onChange={(e) => setReview(e.target.value)}
            placeholder="Share your thoughts..."
            className="w-full resize-none bg-muted/30 rounded-xl px-4 py-3
                     placeholder:text-muted-foreground/50
                     focus:outline-none focus:ring-2 focus:ring-primary/20
                     transition-all duration-300"
            rows={4}
            style={{
              fontFamily: "var(--font-sans)",
            }}
          />
        </div>
      </div>

      {/* Follow-up questions */}
      <div className="px-6 pb-6 space-y-8">
        {questions.map((question, index) => (
          <div
            key={question.id}
            className="opacity-0 animate-slide-in"
            style={{
              animationDelay: `${(index + 1) * 200}ms`,
              animationFillMode: "forwards",
            }}
          >
            {/* Question category indicator */}
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-[13px] font-medium">
                  {index + 2}
                </span>
              </div>
              <span className="text-[13px] text-muted-foreground">
                {question.category}
              </span>
            </div>

            {/* Question card with rating */}
            <div className="bg-white rounded-2xl px-5 py-5 shadow-[0_2px_12px_rgba(0,0,0,0.08)]">
              {/* Question text */}
              <p className="text-[15px] leading-relaxed mb-5">
                {question.text}
              </p>

              {/* Star rating */}
              <div className="flex flex-col items-center">
                <p className="text-[13px] text-muted-foreground mb-2.5">
                  Leave rating
                </p>
                <div className="flex items-center gap-2">
                  {Array.from({ length: 5 }).map((_, i) => {
                    const starValue = i + 1;
                    const isActive =
                      starValue <=
                      (hoveredStars[question.id] ||
                        ratings[question.id] ||
                        0);

                    return (
                      <button
                        key={i}
                        onClick={() =>
                          updateRating(question.id, starValue)
                        }
                        onMouseEnter={() =>
                          setHoveredStars((prev) => ({
                            ...prev,
                            [question.id]: starValue,
                          }))
                        }
                        onMouseLeave={() =>
                          setHoveredStars((prev) => ({
                            ...prev,
                            [question.id]: 0,
                          }))
                        }
                        className="transition-all duration-200 hover:scale-110 active:scale-95"
                      >
                        <Star
                          className={`w-9 h-9 transition-colors duration-200 ${
                            isActive
                              ? "fill-primary text-primary"
                              : "fill-none text-foreground/40 stroke-[2.5]"
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Submit button - sticky at bottom */}
      <div className="px-6 pb-6 pt-4 sticky bottom-0 bg-gradient-to-t from-background via-background to-transparent">
        <button
          onClick={handleSubmit}
          className="w-full bg-primary text-primary-foreground py-4 rounded-2xl
                   disabled:opacity-40 disabled:cursor-not-allowed
                   transition-all duration-300
                   shadow-[0_4px_16px_rgba(238,194,24,0.24)]
                   hover:shadow-[0_6px_20px_rgba(238,194,24,0.32)]
                   hover:scale-[1.02]
                   active:scale-[0.98]
                   disabled:hover:scale-100 disabled:hover:shadow-[0_4px_16px_rgba(238,194,24,0.24)]"
        >
          Submit review
        </button>
      </div>

      {/* Decorative gradient orb */}
      <div
        className="fixed top-0 right-0 w-64 h-64 rounded-full opacity-20 blur-3xl pointer-events-none -z-10"
        style={{
          background:
            "radial-gradient(circle, #EEC218 0%, transparent 70%)",
          animation: "float 8s ease-in-out infinite",
        }}
      />

      <style>{`
        @keyframes float {
          0%, 100% { transform: translate(20%, -20%); }
          50% { transform: translate(10%, -30%); }
        }
        @keyframes slide-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-slide-in {
          animation: slide-in 0.5s ease-out;
        }
      `}</style>
    </div>
  );
}