import { Mic } from 'lucide-react';
import { useEffect } from 'react';

interface VoiceButtonProps {
  isRecording: boolean;
  onToggle: () => void;
  onTranscript: (text: string) => void;
}

export function VoiceButton({ isRecording, onToggle, onTranscript }: VoiceButtonProps) {
  useEffect(() => {
    if (isRecording) {
      // Simulate transcription after 2 seconds
      const timer = setTimeout(() => {
        const mockTranscripts = [
          "The hotel was beautiful and the staff were incredibly friendly.",
          "Room was spacious with a great view of the city.",
          "Breakfast buffet had excellent variety and quality.",
          "Location was perfect, walking distance to everything."
        ];
        const randomTranscript = mockTranscripts[Math.floor(Math.random() * mockTranscripts.length)];
        onTranscript(randomTranscript);
        onToggle();
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [isRecording, onTranscript, onToggle]);

  return (
    <button
      onClick={onToggle}
      className={`
        relative w-14 h-14 rounded-full flex items-center justify-center
        transition-all duration-300
        ${isRecording
          ? 'bg-primary text-primary-foreground shadow-[0_0_24px_rgba(238,194,24,0.5)]'
          : 'bg-white text-foreground shadow-[0_2px_12px_rgba(0,0,0,0.1)] hover:shadow-[0_4px_16px_rgba(238,194,24,0.2)]'
        }
      `}
    >
      <Mic className={`w-5 h-5 ${isRecording ? 'animate-pulse' : ''}`} />

      {isRecording && (
        <>
          {/* Pulsing rings */}
          <span className="absolute inset-0 rounded-full border-2 border-primary animate-ping opacity-75" />
          <span className="absolute inset-0 rounded-full border border-primary animate-pulse" />
        </>
      )}
    </button>
  );
}
