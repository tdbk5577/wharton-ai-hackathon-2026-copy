import { useState } from 'react';
import { PropertyIntro } from './components/PropertyIntro';
import { ReviewForm } from './components/ReviewForm';
import { ProcessingState } from './components/ProcessingState';
import { CompletionState } from './components/CompletionState';

type AppState = 'intro' | 'review' | 'processing' | 'completed';

export default function App() {
  const [state, setState] = useState<AppState>('intro');

  const handleStartReview = () => {
    setState('review');
  };

  const handleReviewSubmit = () => {
    setState('processing');

    // Simulate processing time
    setTimeout(() => {
      setState('completed');
    }, 2000);
  };

  return (
    <div className="size-full flex items-center justify-center bg-background">
      {/* Mobile container */}
      <div className="w-full h-full max-w-md mx-auto relative overflow-hidden">
        {/* Background texture */}
        <div
          className="absolute inset-0 opacity-[0.015] pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />

        {/* Main content with smooth transitions */}
        <div className="relative h-full">
          {state === 'intro' && (
            <div
              className="h-full opacity-0 animate-fade-in"
              style={{
                animationDelay: '100ms',
                animationFillMode: 'forwards',
              }}
            >
              <PropertyIntro onStartReview={handleStartReview} />
            </div>
          )}

          {state === 'review' && (
            <div
              className="h-full opacity-0 animate-fade-in"
              style={{
                animationDelay: '100ms',
                animationFillMode: 'forwards',
              }}
            >
              <ReviewForm onSubmit={handleReviewSubmit} />
            </div>
          )}

          {state === 'processing' && (
            <div
              className="h-full opacity-0 animate-fade-in"
              style={{
                animationFillMode: 'forwards',
              }}
            >
              <ProcessingState />
            </div>
          )}

          {state === 'completed' && (
            <div
              className="h-full opacity-0 animate-fade-in"
              style={{
                animationFillMode: 'forwards',
              }}
            >
              <CompletionState />
            </div>
          )}
        </div>
      </div>

      <style>{`
        @keyframes fade-in {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        .animate-fade-in {
          animation: fade-in 0.4s ease-out;
        }
      `}</style>
    </div>
  );
}